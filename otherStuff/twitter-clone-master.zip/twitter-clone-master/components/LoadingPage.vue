<template>
    <div class="flex items-center justify-center h-screen">
        <div class="absolute w-20 h-20 animate-ping">
            <LogoTwitter />
        </div>
    </div>
</template>
<script setup>

</script>